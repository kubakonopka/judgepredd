# JudgePredd - Instrukcja uruchomienia

Ten plik zawiera zbudowaną wersję aplikacji JudgePredd wraz z danymi eksperymentów.

## Wymagania
- Dowolny serwer HTTP (np. Python SimpleHTTPServer, Node http-server, nginx, Apache)

## Instrukcja uruchomienia

1. Rozpakuj archiwum:
```bash
tar -xzf judgepredd.tar.gz
```

2. Skopiuj zawartość katalogu `build` do głównego katalogu serwera HTTP

3. Skopiuj katalog `public/mlflow_results` do katalogu z plikami statycznymi serwera

4. Uruchom serwer HTTP. Przykłady:

Używając Python:
```bash
cd build
python3 -m http.server 8000
```

Używając Node.js:
```bash
npm install -g http-server
cd build
http-server
```

5. Otwórz przeglądarkę i przejdź pod adres:
- Dla Python: http://localhost:8000
- Dla http-server: http://localhost:8080

## Struktura danych

Dane eksperymentów znajdują się w katalogu `mlflow_results`. Struktura:

```
mlflow_results/
  experiments.json         # Konfiguracja eksperymentów
  1. results_basic_prompts/
    run.json              # Wyniki eksperymentu
    data.json             # Dodatkowe dane
    description.txt       # Opis eksperymentu
  2. results_perfect_prompts/
    ...
```

## Dodawanie nowych eksperymentów

Aby dodać nowy eksperyment:

1. Utwórz nowy katalog w `mlflow_results` z nazwą w formacie: `[numer]. [nazwa_eksperymentu]`
2. Dodaj pliki `run.json`, `data.json` i `description.txt`
3. Dodaj wpis w `experiments.json` z informacjami o nowym eksperymencie

## Problemy?

Jeśli występują problemy:
1. Sprawdź czy wszystkie pliki są w odpowiednich lokalizacjach
2. Sprawdź czy serwer HTTP ma uprawnienia do odczytu plików
3. Sprawdź w konsoli przeglądarki (F12) czy nie ma błędów ładowania plików
